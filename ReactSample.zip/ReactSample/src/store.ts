import createStore from "fragstore"

export const { useStore: useRequest } = createStore({ project:'',step: 0, upFiles: [] })
export const { useStore: useCounter } = createStore({ count: 0 })
