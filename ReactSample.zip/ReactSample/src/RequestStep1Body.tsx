/**RequestStep1Body */
import * as React from 'react';
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import { useRequest } from './store';

const RequestStep1Body = () => {
    //const step = 2;
    const [step, setstep] = useRequest.step();
    function _onStepClicked() {
        setstep(2);
    }
  
    return (
        <div style={{
            width: '100%', height: '200px', justifyContent: 'center',//textAlign: 'center',
            display: 'flex', border: 'solid .5px red', alignItems: 'center'}} >
            RequestStep1Body <p> Current Step {step}</p>
            <PrimaryButton text="Go to Step 2" onClick={_onStepClicked} />
        </div>
    );
};
export default RequestStep1Body;