import React from 'react';

import './App.css';
import { useRequest } from './store';
import RequestHeader from './RequestHeader';
import RequestStep1Body from './RequestStep1Body';
import RequestStep2Body from './RequestStep2Body';
import RequestStep3Body from './RequestStep3Body';


function App() {
// eslint-disable-next-line
  const [step, setstep] = useRequest.step(1);

  return (
    <div className="App">
      <div ><p> Current Step {step}</p>
        <div><RequestHeader /></div>
        {step === 1 && <div><RequestStep1Body /></div>}
        {step === 2 && <div><RequestStep2Body /></div>}
        {step === 3 && <div><RequestStep3Body /></div>}
      </div>
    </div>
  );
}

export default App;
