/**RequestHeader http://jsfiddle.net/danield770/4rrL4/594/*/
import * as React from 'react';
 import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
 import { useRequest } from './store';

const RequestHeader = () => {
     const [step,setstep] = useRequest.step();
    function _onStepClicked(e:any) {
        //console.log(e);
        switch (e.target.innerText) {
            case 'Step 1': setstep(1); break;
            case 'Step 2': setstep(2); break;
            case 'Step 3': setstep(3); break;
            default:                break;
        }  
    }
    
    return (
        <div style={{
            width: '100%', height: '200px', justifyContent: 'center',//textAlign: 'center',
            display: 'flex', border: 'solid .5px red', alignItems: 'center'
        }} >
            <span style={{ margin: '10px' }}>RequestHeader {step }</span>
            <PrimaryButton text="Step 1" onClick={_onStepClicked} />
            <PrimaryButton text="Step 2" onClick={_onStepClicked} />
            <PrimaryButton text="Step 3" onClick={_onStepClicked} />
            
        </div>
    );
};
export default RequestHeader;