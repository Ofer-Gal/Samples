/**RequestStep3Body */
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import * as React from 'react';
 import { useRequest } from './store';
const RequestStep3Body = () => {
    //const step = 3;
    const [step, setstep] = useRequest.step();
    function _onStepClicked() {
       setstep(1);
    }
    
    return (
        <div style={{
            width: '100%', height: '200px', justifyContent: 'center',//textAlign: 'center',
            display: 'flex', border: 'solid .5px red', alignItems: 'center' }} >
            RequestStep3Body [{step}]
            <PrimaryButton text="Go to Step 1" onClick={_onStepClicked} />
        </div>
    );
};
export default RequestStep3Body;