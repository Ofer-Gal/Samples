declare interface IAce2StepsRequestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Ace2StepsRequestWebPartStrings' {
  const strings: IAce2StepsRequestWebPartStrings;
  export = strings;
}
