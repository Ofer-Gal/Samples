import * as React from "react";
import { IAce2StepsRequestProps, IDocumentInfo } from './IAce2StepsRequestProps';
import { BaseComponentContext } from '@microsoft/sp-component-base';

//fluentUI
import { Stack, IStackTokens } from 'office-ui-fabric-react/lib/Stack';
import { ComboBox } from 'office-ui-fabric-react/lib/ComboBox';
import { Checkbox } from "office-ui-fabric-react/lib/Checkbox";


//My 
import { getAllProjects } from "../../../hooks/useSPApps";
import { useECGProject } from "../../../hooks/store";
import FilesComponent from "./FilesComponent";
import FileServicesComponent from "./FileServicesComponent";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";

//Step1 ,Step 2
//#region Styles
const headingStackTokens: IStackTokens = { childrenGap: 20 }; // Tokens definition

const comboxStyles = {
    container: { width: '90%', marginLeft: '10px' },
    label: { fontWeight: '450', fontStyle: 'italic' }
};
const smallComboxStyle = {
    container: { width: '70%', marginLeft: '10px' },
    label: { fontWeight: '450', fontStyle: 'italic' }
};
const checkBoxStyle = {
    root: { top: '35px' },
    container: { width: '30%', marginLeft: '10px' },
    label: { fontWeight: '450', fontStyle: 'italic' }
};
//#endregion Styles


/*-----------------------Start of Root Component---------------------------------*/
export const RootComponent = (props: IAce2StepsRequestProps) => {
    const [upfiles] = useECGProject.upfiles();
    const [theProject, setTheProject] = useECGProject.theProject();
    const [projects, setProjects] = React.useState([]);
    const [projectNumbers, setProjectNumbers] = React.useState([]);
    const [selectedProject, setSelectedProject] = React.useState({ text: null, key: null, ID: null });
    const [stepMessage, setStepMessage] = React.useState('');
    const [readyForNext, setReadyForNext] = React.useState(false);
    const [requestStep, setRequestStep] = useECGProject.requestStep();
    const [filesdisplay, setFilesdisplay] = React.useState('none');
    React.useEffect(() => { //ueh ---To Do Filter by users groups---------------------
        const load = async () => {
            const p = await getAllProjects();
            setProjects(p.sort((a, b) => a.text.localeCompare(b.text)));
            setProjectNumbers(p.map(x => ({ text: x.key, key: x.key, ID: x.ID })).sort((a, b) => a.text.localeCompare(b.text)));
        };
        load();
    }, []);
    const _nextStep = () => {
        setRequestStep(3);  //alert('Next');
        //props.setStepMessage('Step 3 Apply services and pages to the files');
    };
    React.useEffect(() => { //ueh ---To Do Filter by users groups---------------------
        switch (requestStep) {
            case 1: setStepMessage('Step 1 Choose a Project'); break;
            case 2: setStepMessage('Step 2 Add files to the request'); setFilesdisplay('block'); break;
            case 3: setStepMessage('Step 3 Apply services and pages to the files'); setFilesdisplay('none'); break;
            case 4: setStepMessage('Step 4 Apply additional data to the request'); break;
            default: break;
        }
    }, [requestStep]);

    const selectProject = (e, selectedOption) => {
        const selText = (selectedOption.text === selectedOption.key) ?
            projects.find(x => x.key === selectedOption.key).text : selectedOption.text;
        setSelectedProject({ text: selText, key: selectedOption.key, ID: selectedOption.ID });
        setRequestStep(2);
        setTheProject(selectedOption.key);
    };

    return ( //Later allow selecting CRM pipline for proposalstextAlign: 'center'
        <div >
            {/* <span style={{ textDecoration: 'underline', fontStyle: 'oblique' }}>{stepMessage}</span>
            {readyForNext && <PrimaryButton text="Next Step" onClick={_nextStep} />}
            <Stack horizontal horizontalAlign="space-between" tokens={headingStackTokens}>
                <Stack grow>
                    <ComboBox placeholder="Select Project Name" label="All Projects" options={projects}
                        onChange={selectProject} text={selectedProject.text} styles={comboxStyles} disabled={upfiles.length > 0}
                    />
                </Stack>
                <Stack grow>
                    <Stack horizontal horizontalAlign="space-between" tokens={headingStackTokens}>
                        <ComboBox placeholder="Select Project Number" label="Project numbers" options={projectNumbers}
                            onChange={selectProject} text={selectedProject.key} styles={smallComboxStyle} disabled={upfiles.length > 0}
                        />
                        <span><Checkbox label='Show All' boxSide="end" styles={checkBoxStyle} disabled={upfiles.length > 0}
                        /></span>
                    </Stack>
                </Stack>
            </Stack>

            <div style={{ display: filesdisplay }}>
                <FilesComponent context={props.context} setReadyForNext={setReadyForNext}/>
            </div> */}
            {(requestStep === 3) && 
                <FileServicesComponent />
            }
        </div>
    );
};

