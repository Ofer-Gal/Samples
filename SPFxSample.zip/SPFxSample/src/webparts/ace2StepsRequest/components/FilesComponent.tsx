/**FilesComponent */
import * as React from "react";

import { TooltipHost } from "office-ui-fabric-react/lib/Tooltip";
import { PrimaryButton } from "office-ui-fabric-react/lib/components/Button";
import { Stack } from "office-ui-fabric-react/lib/Stack";

import { FilePicker, IFilePickerResult } from "@pnp/spfx-controls-react/lib/FilePicker";
//import {unique} from "array-unique"
//My
import { deleteProjectFile, postProjectFiles, replaceProjectFile, replaceProjectFileDN } from "../../../hooks/useSPProject";
import styles from './Ace2StepsRequest.module.scss';
import { IDocumentInfo } from "./IAce2StepsRequestProps";
import { useECGProject } from "../../../hooks/store";


/*-----------------------Start of Files Component---------------------------------*/
const FilesComponent = (props) => {
    //const [requestStep, setRequestStep] = useRequestStep.requestStep();, useRequestStep
    const [upfiles, setUpfiles] = useECGProject.upfiles();
    const [theProject] = useECGProject.theProject();
    const [currentMessage, setcurrentMessage] = React.useState('');
    const [actionDisplay, setActionDisplay] = React.useState('none');


    function containsOnly(array1, array2) {
        return array2.every(elem => array1.includes(elem))
    }

    React.useEffect(() => { //ueh  All file status is Ready or replaced
        if (upfiles.length > 0 && containsOnly(["Ready", "Replaced"], upfiles.map(f => f.status))) { // console.log('yes'); // "Ready", "Replaced" continue to step 3 button
            props.setReadyForNext(true);
        } else {
            props.setReadyForNext(false);
        }
    }, [upfiles]);



    const _onFilePickerSave = async (Results: IFilePickerResult[]) => {
        setActionDisplay('none');
        const docs: IDocumentInfo[] = Results.map((x, i) => ({ file: x, status: 'New' }));
        const postResuls = await postProjectFiles(theProject, docs, setcurrentMessage);  //Uploading to SPO
        postResuls.forEach((r, i) => {
            const saveFile = docs[i].file;
            docs[i] = r;
            docs[i].file = saveFile;
        });
        const newFiles = upfiles.concat(docs);
        setActionDisplay('inline');
        setUpfiles(newFiles); //setFiles(newFiles);
    };
    const _onReadyItem = (i: number) => {
        setUpfiles(upfiles.map((upfile, index) => index === i ? { ...upfile, status: "Ready" } : upfile))
    };
    const _onRemoveNewItem = async (i: number) => {
        setActionDisplay('none');
        await deleteProjectFile(theProject, upfiles[i], upfiles[i].itemId, setcurrentMessage);
        setUpfiles(upfiles.filter((f) => f !== upfiles[i]));
        //setUpfiles([...upfiles.map((upfile, index) => index === i ? { ...upfile, status: "X" } : upfile)])
        setActionDisplay('inline');
    };
    const _onRemoveItem = (i: number) => {  //Do not delete the file
        setUpfiles(upfiles.filter((f) => f !== upfiles[i]));
        //setUpfiles([...upfiles.map((upfile, index) => index === i ? { ...upfile, status: "X" } : upfile)])
    };
    const _onReplaceItem = async (i: number) => { // e is a RowNode  e.data is the file property
        setActionDisplay('none');
        await replaceProjectFile(theProject, upfiles[i], setcurrentMessage);
        setUpfiles(upfiles.map((upfile, index) => index === i ? { ...upfile, status: "Replaced" } : upfile))
        setActionDisplay('inline');
    };

    const _onReplaceItemDN = async (i: number) => {
        setActionDisplay('none');
        await replaceProjectFileDN(theProject, upfiles[i], upfiles[i].itemId, upfiles[i].sameNumberFileName, setcurrentMessage);
        setUpfiles(upfiles.map((upfile, index) => index === i ? { ...upfile, status: "Replaced" } : upfile))
        setActionDisplay('inline');
    };

    function formatBytes(a: number, b = 2) { if (0 === a) return "0 Bytes"; const c = 0 > b ? 0 : b, d = Math.floor(Math.log(a) / Math.log(1024)); return parseFloat((a / Math.pow(1024, d)).toFixed(c)) + " " + ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d]; }
    function byteFormatter(params) {
        if (Number.isInteger(params)) {
            return formatBytes(params);
        }
        return '';
    }
    const rowBackground = (status: string) => {
        switch (status) {
            case 'ExistsInProject': return 'rgb(247, 212, 212)';// exists In Project
                break;
            case 'SameDocNumber': return 'rgb(230, 213, 182)';//older version exists light orange
                break;
            case 'New': return '';
                break;
            default: return 'rgb(131, 255, 127)'; //Totaly new or ready ('Replaced,Ready'.includes(param.data.status) ){
                break;
        }
    };

    const fileNameLinkRender = (f) => {
        if (f.existsUrlInProject) {
            return (<span><a href={f.existsUrlInProject} target="_blank" rel="noopener noreferrer"> {f.file.fileName} </a></span>);
        } else {
            return (<span>{f.file.fileName}</span>);//param.value
        }
    };
    const DocNumberLinkRender = (f) => {
        if (f.documentNumber && f.sameNumberFileName) { //param.data.existsInProject && <a href={parm.data.ecg_projectworksite} rel="noopener noreferrer"  >{parm.value}</a>
            return (<span>
                <a href={f.existsUrlInProject} target="_blank" rel="noopener noreferrer" > {f.documentNumber} </a> &nbsp; {f.sameNumberFileName}
            </span>);
        } else {
            if (f.documentNumber) {
                return (<span>{f.documentNumber}</span>);
            } else {
                return (<span></span>);
            }
        }
    };



    const ActionRender = (i) => {
        switch (upfiles[i].status) {
            case 'ExistsInProject': return (<span>
                <TooltipHost content={`File ${upfiles[i].file.fileName} will be replaced with the new one`}  >
                    <button onClick={e => _onReplaceItem(i)}>Replace</button>
                </TooltipHost>
                <TooltipHost content={`File ${upfiles[i].file.fileName} will be removed from Request`}  >
                    <button onClick={e => _onRemoveItem(i)}>Remove</button>
                </TooltipHost></span>);
                break;
            case 'SameDocNumber': return (<span>
                <TooltipHost content={`File ${upfiles[i].sameNumberFileName} will be replaced with ${upfiles[i].file.fileName}`}  >
                    <button onClick={e => _onReplaceItemDN(i)}>Replace</button>

                </TooltipHost >
                <TooltipHost content={`Both files ${upfiles[i].sameNumberFileName} and ${upfiles[i].file.fileName} with new Document number `}  >
                    <button onClick={e => _onReadyItem(i)}>As New</button>

                </TooltipHost>
                <TooltipHost content={`File ${upfiles[i].file.fileName} will be removed from Request`}  >
                    <button onClick={e => _onRemoveNewItem(i)}>Remove</button>
                </TooltipHost>   </span >);//older version exists light orange , param.data.itemId
                break;
            default: return (<span>
                <TooltipHost content={`File ${upfiles[i].file.fileName} will be removed from Request`}  >
                    <button onClick={e => _onRemoveNewItem(i)}>Remove</button>
                </TooltipHost></span>); //Totaly new or ready , param.data.itemId
                break;
        }
    };

    // const actionDisplay = () => {
    //     if
    // };
    return (
        <div>
            <Stack horizontal horizontalAlign="start">
                <div style={{ padding: '5px', width: '20%', }}>                     {/*  */}
                    <FilePicker buttonLabel={'Add Files'}
                        includePageLibraries={false} hideOrganisationalAssetTab hideLocalUploadTab
                        hideRecentTab hideStockImages storeLastActiveTab={true}
                        onSave={_onFilePickerSave} hideSiteFilesTab
                        context={props.context}
                    />
                </div>
                <div style={{ padding: '5px', width: '80%', textAlign: 'center' }}>
                    {/*  */}
                    {currentMessage}
                </div>
                {/* <div style={{ padding: '5px', width: '15%', textAlign: 'right' }}></div> */}
            </Stack>
            {/* style={{ border: '1px solid black', borderCollapse: 'collapse', width: '100%' }}  */}
            <Stack>
                {(upfiles.length > 0) && <table className={styles.myTable}  >
                    <tr>
                        <th className={styles.myColumns}>Name</th>
                        <th style={{ width: '10%', border: '1px solid black' }}>Size</th>
                        <th >Id</th>
                        <th style={{ width: '20%', border: '1px solid black' }}>Status</th>
                        <th style={{ width: '15%', border: '1px solid black' }}>Doc Number</th>
                        <th style={{ width: '30%', border: '1px solid black' }}>Action</th>
                    </tr>
                    {upfiles.map((file, i) => {
                        return <tr key={i} style={{ background: rowBackground(file.status) }}>
                            <td className={styles.myColumns}>{fileNameLinkRender(file)}</td>
                            <td className={styles.myColumns}>{byteFormatter(file.fileSize)}</td>
                            <td className={styles.myColumns}>{file.itemId}</td>
                            <td className={styles.myColumns}>{file.status}</td>
                            <td className={styles.myColumns}>{DocNumberLinkRender(file)}</td>
                            <td className={styles.myColumns} style={{ display: actionDisplay }}>
                                {ActionRender(i)}
                            </td>
                        </tr>
                    })}
                </table>}
            </Stack>
            {/* <br />
            {(upfiles) && <div>
                <pre>
                    {JSON.stringify(upfiles.map(s => s.status), null, 2)}
                </pre>
            </div>}
            <br />
            {(upfiles) && <div>
                <pre>
                    {JSON.stringify(upfiles, null, 2)}
                </pre>
            </div>} */}
        </div>
    );
};

export default FilesComponent;
