import * as React from 'react';
import styles from './Ace2StepsRequest.module.scss';
import { IAce2StepsRequestProps } from './IAce2StepsRequestProps';
import { escape } from '@microsoft/sp-lodash-subset';


import { RootComponent } from './RootComponent';
//import store from '../../../hooks/store';

const Ace2StepsRequest = (props: IAce2StepsRequestProps) => {
  return (
    <div className={styles.ace2StepsRequest}>
        <div>
          <RootComponent {...props} />
        </div>
    </div>
  );
};

export default Ace2StepsRequest;