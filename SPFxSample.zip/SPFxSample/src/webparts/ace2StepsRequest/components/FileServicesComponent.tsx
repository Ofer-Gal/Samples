/**FileServicesComponent.tsx */
import * as React from "react";
import { TooltipHost } from "office-ui-fabric-react/lib/Tooltip";
import styles from './Ace2StepsRequest.module.scss';
import { useECGProject } from "../../../hooks/store";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { SpinButton } from "office-ui-fabric-react/lib/SpinButton";

/*-----------------------Start of Files Component---------------------------------*/
const FileServicesComponent = (props) => {
  //const [upfiles, setUpfiles] = useECGProject.upfiles();
  // const [upfiles, setUpfiles] = React.useState([
  //   { key: 1, file: `Test1.docx` }, { key: 1, file: `Test2.docx` }, { file: `Test3.docx` }
  // ]);
  const [upfiles, setUpfiles] = React.useState([{  file: `Test1.docx` }, {  file: `Test2.docx` }, { file: `Test3.docx` }]);
  // React.useEffect(() => { //ueh ---To Do Filter by users groups---------------------
  //     for (let index = 0; index < 5; index++) {
  //       upfiles.push({file:`Test${index+1}.docx`});
  //     }
  // }, []);

    return (
      <div>
        {/* {(upfiles.length > 0) && */}
          <table className={styles.myTable}  >
          <tr>
            <th className={styles.myColumns}>Name</th>
            <th style={{ width: '30%', border: '1px solid black' }}>Services</th>
            <th style={{ width: '10%', border: '1px solid black' }}>Pages</th>
            <th style={{ width: '30%', border: '1px solid black' }}>Instructions</th>

          </tr>
          {upfiles.map((file, i ) => {
            return <tr key={i} >
              {/* <td className={styles.myColumns}>{file.file.fileName}</td>*/}
              <td className={styles.myColumns}>{file}</td>
              <td className={styles.myColumns}>Services</td>
              <td className={styles.myColumns}>
                <SpinButton defaultValue='0' min={0} max={999} />
              </td>
              <td className={styles.myColumns}>
                <TextField  multiline autoAdjustHeight />
              </td>
            </tr>
          })}
          </table>
        

        </div>
    );
};
export default FileServicesComponent;