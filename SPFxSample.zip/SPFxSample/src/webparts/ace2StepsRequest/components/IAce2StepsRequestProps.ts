import { IFilePickerResult } from "@pnp/spfx-controls-react/lib/FilePicker";
//import { BaseComponentContext } from '@microsoft/sp-component-base';
import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IAce2StepsRequestProps {
  description: string;
  context: WebPartContext;
}

export interface IDocumentInfo { //  index: number;
  status: string;
  file: IFilePickerResult;
  itemId?: number;
  pages?: number;
  instructions?: string;
  documentNumber?: string;
  requestNumber?: string;
  sameNumberFileName?: string;
  sameNumberFileId?: number;
  fileSize?: number;
  existsUrlInProject?: string;
}
