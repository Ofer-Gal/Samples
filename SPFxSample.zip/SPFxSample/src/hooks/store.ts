
import createStore from "fragstore";

// const useStore = createStore({
//     upfiles: [],
//     projectNumber: 'None'
// });
export const { useStore: useECGProject } = createStore({ upfiles: [], theProject: 'None', requestStep: 3 });
//export const {  useStore: useRequestStep } = createStore({ requestStep: 1 });
