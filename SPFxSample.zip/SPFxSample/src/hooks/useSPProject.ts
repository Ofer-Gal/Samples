//PNP/SP
//PnP
import { sp } from "@pnp/sp";
import { Web } from "@pnp/sp/webs";
import { IItemAddResult } from "@pnp/sp/items";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import "@pnp/sp/folders";
//spfx-controls-react
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';

//My
import { IDocumentInfo } from "../webparts/ace2StepsRequest/components/IAce2StepsRequestProps";



export const postProjectFile = async (projectNumber: string, file: IFilePickerResult) => {

    const siteUrl = '/teams/' + projectNumber; //window.location.origin + '/teams/'+projectNumber ;
    let web = Web(siteUrl);
    const fixFileName = file.fileName.split(`'`).join();
    const blob = await file.downloadFileContent();
    //if (!file.file.fileSize) file.file.fileSize = blob.size;
    try {
        let uFile = await web.getFolderByServerRelativeUrl(`${siteUrl}/DPCDocuments/`).files.addChunked(fixFileName, blob, data => {
            //setcurrentMessage(`${file.fileName} ${data.stage} part #${data.blockNumber}`);
        }, false); // without replace first time (true)
        const item: any = await uFile.file.getItem();
        //console.log(item); //do we get document number? record the item.ID !!!!!!!item.DocumentNumber item.Id item.ProjectNumber item.RequestNumber
        //setcurrentMessage(file.fileName + " loaded as Item #" + item.ID);
        if (item.DocumentNumber) {//If there is a DocumentNumber, look for it in same project
            const items: any = await web.lists.getByTitle("DPC Documents").items.select('ID,FileLeafRef,ServerRedirectedEmbedUrl,DocumentNumber,Modified')
                .filter(`DocumentNumber eq '${item.DocumentNumber}' and FileLeafRef ne '${fixFileName}'`).get();
            if (items.length > 0) {
                //setcurrentMessage(file.fileName + " Found other file with same Document Number " + items[0].FileLeafRef);
                return {
                    file: file, itemId: item.ID, documentNumber: item.DocumentNumber,
                    existsUrlInProject: items[0].ServerRedirectedEmbedUrl, fileSize: blob.size,
                    sameNumberFileName: items[0].FileLeafRef, sameNumberFileId: items[0].ID, status: 'SameDocNumber'
                };
            } else {
                return { file: file, itemId: item.ID, fileSize: blob.size, status: 'Ready' };//Same as New
            }
        } else {
            return { file: file, itemId: item.ID, fileSize: blob.size, status: 'Ready' }; //index: file.index,
        }
    } catch (error) {
        //console.log(`Error:${error.message}`); //
        if (error.message.includes('already exists')) {
            //setcurrentMessage(file.fileName + " already exists ");
            const items: any = await web.lists.getByTitle("DPC Documents").items.select('ID,ServerRedirectedEmbedUrl,DocumentNumber,Modified,RequestNumber').filter(`FileLeafRef eq '${fixFileName}'`).get();
            //console.log(items[0]); index: file.index,
            return {
                file: file, itemId: items[0].ID, documentNumber: items[0].DocumentNumber, fileSize: blob.size,
                status: 'ExistsInProject', existsUrlInProject: items[0].ServerRedirectedEmbedUrl, requestNumber: items[0].RequestNumber
            };
        } else {
            //console.log(`Error:${error.message}`);
            alert(error.message);
            //setcurrentMessage(file.fileName + " error: " + error.message);
        }
    }
};
export const postProjectFiles = async (projectNumber: string, files: IDocumentInfo[], setcurrentMessage) => {
    const postResuls = [];
    const siteUrl = '/teams/' + projectNumber; //window.location.origin + '/teams/'+projectNumber ;
    let web = Web(siteUrl);

    for (let index = 0; index < files.length; index++) { //(let index = files.length - 1; index > -1; index--) {
        const fixFileName = files[index].file.fileName.split(`'`).join();
        if (files[index].file.fileAbsoluteUrl) setcurrentMessage(`Downloading ${fixFileName}`); 
        const blob = await files[index].file.downloadFileContent();
        try {
            let file = await web.getFolderByServerRelativeUrl(`${siteUrl}/DPCDocuments/`).files.addChunked(fixFileName, blob, data => {
                setcurrentMessage(`${files[index].file.fileName} ${data.stage} part #${data.blockNumber}`);
            }, false); // without replace first time (true)
            const item: any = await file.file.getItem();
            //do we get document number? record the item.ID !!!!!!!item.DocumentNumber item.Id item.ProjectNumber item.RequestNumber
            setcurrentMessage(files[index].file.fileName + " loaded as Item #" + item.ID);
            if (item.DocumentNumber) {//If there is a DocumentNumber, look for it in same project
                const items: any = await web.lists.getByTitle("DPC Documents").items.select('ID,FileLeafRef,ServerRedirectedEmbedUrl,DocumentNumber,Modified')
                    .filter(`DocumentNumber eq '${item.DocumentNumber}' and FileLeafRef ne '${fixFileName}'`).get();
                if (items.length > 0) {
                    setcurrentMessage(files[index].file.fileName + " Found other file with same Document Number " + items[0].FileLeafRef);
                    postResuls.push({ //index: files[index].index,
                         itemId: item.ID, documentNumber: item.DocumentNumber,
                        existsUrlInProject: items[0].ServerRedirectedEmbedUrl, fileSize: blob.size,
                        sameNumberFileName: items[0].FileLeafRef, sameNumberFileId: items[0].ID, status: 'SameDocNumber'
                    });
                } else {
                    postResuls.push({  itemId: item.ID, fileSize: blob.size, status: 'Ready' });//Same as New
                }
            } else {
                postResuls.push({  itemId: item.ID, fileSize: blob.size,status: 'Ready' });
            }
        } catch (error) {            //console.log(`Error:${error.message}`); //
            if (error.message.includes('already exists')) {
                setcurrentMessage(files[index].file.fileName + " already exists ");
                const items: any = await web.lists.getByTitle("DPC Documents").items.select('ID,ServerRedirectedEmbedUrl,DocumentNumber,Modified,RequestNumber').filter(`FileLeafRef eq '${fixFileName}'`).get();
                postResuls.push({
                    itemId: items[0].ID, documentNumber: items[0].DocumentNumber, fileSize: blob.size,
                    status: 'ExistsInProject', existsUrlInProject: items[0].ServerRedirectedEmbedUrl, requestNumber: items[0].RequestNumber
                });
                //continue;
            } else {
                console.log(`Error:${error.message}`);
                //alert(error.message);
                setcurrentMessage(files[index].file.fileName + " error: " + error.message);
            }
        }
    }
    setcurrentMessage(postResuls.length + " files loaded");
    return postResuls;

};
export const deleteProjectFile = async (projectNumber: string, file: IDocumentInfo, itemId: number, setcurrentMessage) => {
    try {
        const web = Web('/teams/' + projectNumber);
        await web.lists.getByTitle("DPC Documents").items.getById(itemId).delete();
        setcurrentMessage(file.file.fileName + " deleted ");
    } catch (error) {
        console.log(error.message); //Item does not exist
        setcurrentMessage(file.file.fileName + " error: Item does not exist"); //+ error.message);
    }
};
export const replaceProjectFileDN = async (projectNumber: string, file: IDocumentInfo, itemId: number, sameNumberFileName: string, setcurrentMessage: (arg0: string) => void) => {
    const fixFileName = file.file.fileName.split(`'`).join();
    try { //replace the old name with the new and delete the new
        const siteUrl = '/teams/' + projectNumber; //window.location.origin + '/teams/'+projectNumber ;
        let web = Web(siteUrl);
        let blob = await file.file.downloadFileContent();
        let fileChange = await web.getFolderByServerRelativeUrl(`${siteUrl}/DPCDocuments/`).files.addChunked(sameNumberFileName, blob, data => {
            setcurrentMessage(`${fixFileName} ${data.stage} part #${data.blockNumber}`);
        }, true); // with replace for replace (true)
        const item: any = await fileChange.file.getItem();
        //        now delete the file we uploaded otherwise the rest will fail
        await web.lists.getByTitle("DPC Documents").items.getById(itemId).delete();
        setcurrentMessage(fixFileName + " deleted ");
        await item.update({ FileLeafRef: fixFileName });
        await web.getFileByServerRelativeUrl(`${siteUrl}/DPCDocuments/${fixFileName}`).publish("Replace Existing File");// publish with a supplied comment.
        setcurrentMessage(fixFileName + " Published ");
    } catch (error) {
        console.log(error.message);
        setcurrentMessage(fixFileName + " error: " + error.message);
    }
};
// replace by file name
export const replaceProjectFile = async (projectNumber: string, file: IDocumentInfo, setcurrentMessage: (arg0: string) => void) => {
    
    try { //replace the old name with the new and delete the new
        const fixFileName = file.file.fileName.split(`'`).join();
        const siteUrl = '/teams/' + projectNumber; //window.location.origin + '/teams/'+projectNumber ;
        let web = Web(siteUrl);
        let blob = await file.file.downloadFileContent();
        let fileChange = await web.getFolderByServerRelativeUrl(`${siteUrl}/DPCDocuments/`).files.addChunked(fixFileName, blob, data => {
           // console.log(data.stage);
            setcurrentMessage(fixFileName + " " + data.blockNumber);
        }, true); // with replace for replace (true)         const item: any = await fileChange.file.getItem();
        await web.getFileByServerRelativeUrl(`${siteUrl}/DPCDocuments/${fixFileName}`).publish("Replace Existing File");// publish with a supplied comment.
        setcurrentMessage(fixFileName + " Published ");
        //Need set the status to 'Ready'        return { index: file.index, exists: false, status:'Ready' }
    } catch (error) {
        console.log(error.message);
        setcurrentMessage(" error: " + error.message);
    }
};
