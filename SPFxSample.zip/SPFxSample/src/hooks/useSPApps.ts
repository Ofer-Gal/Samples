//PNP/SP
import { Web } from "@pnp/sp/webs";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { PagedItemCollection } from "@pnp/sp/items";
const appWeb = Web(window.location.origin + "/sites/app");

export const getAllProjects = async () => {
    let items: PagedItemCollection<any[]> = null;
    items = await appWeb.lists.getByTitle("ECG-Sites-Master").items
        .select('Title', 'Id', 'ProjectNumber').top(1500)
        .orderBy('Title').filter('DoNotShow eq null or DoNotShow eq false')
        .getPaged();
    let allProjecrs = items.results;
    while (items.hasNext) {     // this will carry over the type specified in the original query for the results array
        items = await items.getNext();
        allProjecrs.push(...items.results);     //console.log(allJobs.length);
    }
    return allProjecrs.map(x => ({ text: (x.Title + " " + x.ProjectNumber), key: x.ProjectNumber, ID: x.Id }));
};
